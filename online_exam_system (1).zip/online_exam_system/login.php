<?php include 'db.php'; session_start(); ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - Online Exam System</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="container">
        <h2>Login</h2>
        <?php
        if(isset($_POST['login'])){
            $email=$_POST['email'];
            $pass=$_POST['password'];

            $stmt = $conn->prepare("SELECT * FROM users WHERE email=?");
            $stmt->bind_param("s", $email);
            $stmt->execute();
            $res = $stmt->get_result();
            $row = $res->fetch_assoc();

            if($row && password_verify($pass, $row['password'])){
                $_SESSION['user']=$row['id'];
                header("Location: exam.php");
                exit();
            } else {
                echo "<div class='error-message'>Login failed! Please check your credentials.</div>";
            }
        }
        ?>
        <form method="post">
            <div class="form-group">
                <label for="email">Email:</label>
                <input type="email" id="email" name="email" required>
            </div>
            <div class="form-group">
                <label for="password">Password:</label>
                <input type="password" id="password" name="password" required>
            </div>
            <input type="submit" name="login" value="Login">
        </form>
        <div class="small-text">
            Don't have an account? <a href="register.php" style="color: #667eea; text-decoration: none;">Register here</a>
        </div>
    </div>
</body>
</html>
