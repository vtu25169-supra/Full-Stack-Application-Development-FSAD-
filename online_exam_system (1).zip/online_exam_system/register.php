<?php include 'db.php'; ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register - Online Exam System</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="container">
        <h2>Register</h2>
        <?php
        if(isset($_POST['submit'])){
            $name=$_POST['name'];
            $email=$_POST['email'];
            $pass=password_hash($_POST['password'], PASSWORD_DEFAULT);

            $stmt = $conn->prepare("INSERT INTO users(name,email,password) VALUES(?,?,?)");
            $stmt->bind_param("sss", $name, $email, $pass);
            if($stmt->execute()){
                echo "<div class='success-message'>Registered successfully! <a href='login.php' style='color: inherit;'>Go to Login</a></div>";
            } else {
                echo "<div class='error-message'>Registration failed! Email might already exist.</div>";
            }
        }
        ?>
        <form method="post">
            <div class="form-group">
                <label for="name">Name:</label>
                <input type="text" id="name" name="name" required>
            </div>
            <div class="form-group">
                <label for="email">Email:</label>
                <input type="email" id="email" name="email" required>
            </div>
            <div class="form-group">
                <label for="password">Password:</label>
                <input type="password" id="password" name="password" required>
            </div>
            <input type="submit" name="submit" value="Register">
        </form>
        <div class="small-text">
            Already have an account? <a href="login.php" style="color: #667eea; text-decoration: none;">Login here</a>
        </div>
    </div>
</body>
</html>
