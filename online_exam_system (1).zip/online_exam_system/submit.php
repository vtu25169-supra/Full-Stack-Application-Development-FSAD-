<?php include 'db.php'; session_start();
if(!isset($_SESSION['user'])){
    header("Location: login.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Results - Online Exam System</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="container">
        <h2>Exam Results</h2>
        <?php
        $score=0;
        $res=$conn->query("SELECT * FROM questions");

        while($row=$res->fetch_assoc()){
            $qid=$row['id'];
            if(isset($_POST['q'.$qid])){
                if($_POST['q'.$qid]==$row['answer']){
                    $score++;
                }
            }
        }

        $user=$_SESSION['user'];
        $totalQuestions = $conn->query("SELECT COUNT(*) as total FROM questions")->fetch_assoc()['total'];
        $stmt = $conn->prepare("INSERT INTO results(user_id,score) VALUES(?,?)");
        $stmt->bind_param("ii", $user, $score);
        $stmt->execute();
        ?>
        <div class="success-message">Exam Submitted Successfully!</div>
        <div class="score-display">Your Score: <?php echo $score; ?>/<?php echo $totalQuestions; ?></div>
        <div style="text-align: center;">
            <a href="index.php" style="display: inline-block; background: #667eea; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px; margin-top: 20px;">Back to Home</a>
        </div>
    </div>
</body>
</html>
