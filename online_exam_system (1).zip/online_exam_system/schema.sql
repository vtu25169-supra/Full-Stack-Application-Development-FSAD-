CREATE DATABASE exam_system;
USE exam_system;

CREATE TABLE users (
 id INT AUTO_INCREMENT PRIMARY KEY,
 name VARCHAR(100),
 email VARCHAR(100),
 password VARCHAR(255)
);

CREATE TABLE questions (
 id INT AUTO_INCREMENT PRIMARY KEY,
 question TEXT,
 opt_a VARCHAR(255),
 opt_b VARCHAR(255),
 opt_c VARCHAR(255),
 opt_d VARCHAR(255),
 answer CHAR(1)
);

CREATE TABLE results (
 id INT AUTO_INCREMENT PRIMARY KEY,
 user_id INT,
 score INT
);
